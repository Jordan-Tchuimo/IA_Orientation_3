/* ============================================================
   CapAvenir CMR — script.js
   ============================================================
   Logique :
   - Authentification simulée (4 comptes, 2 rôles)
   - Persistance via localStorage
   - Redirection dynamique selon le rôle
   - Dashboards adaptés (élève / conseiller)
   - Stepper de progression
   - Chat IA simulé
   - Dark mode persisté
   ============================================================ */


/* ----------------------------------------------------------------
   1. COMPTES SIMULÉS (mock back-end)
   ---------------------------------------------------------------- */
const ACCOUNTS = {
  'eleve1@capavenir.cm': {
    password: '1234',
    role: 'eleve',
    name: 'Nadège Mballa',
    class: 'Terminale C — Lycée Général Leclerc',
    initials: 'NM',
    progression: 65,            // %
    tests_done: 3,              // sur 5
    avg_score: 14.2,            // /20
    next: 'Test MECA',
    parcours: [
      { id: 'profil', name: 'Profil psychotechnique', desc: 'Personnalité, intérêts, motivation', score: 'OK', status: 'done' },
      { id: 'sa',     name: 'Test SA', desc: 'Schémas et abstractions',                          score: '15.8', status: 'done' },
      { id: 'la',     name: 'Test LA', desc: 'Logique appliquée',                                score: '14.1', status: 'done' },
      { id: 'meca',   name: 'Test MECA', desc: 'Raisonnement mécanique',                         score: '—',    status: 'active' },
      { id: 'orient', name: 'Orientation finale', desc: 'Recommandations personnalisées',        score: '—',    status: 'pending' },
    ],
  },
  'eleve2@capavenir.cm': {
    password: '1234',
    role: 'eleve',
    name: 'Junior Tchakounté',
    class: 'Première D — Collège Vogt',
    initials: 'JT',
    progression: 40,
    tests_done: 2,
    avg_score: 12.6,
    next: 'Test LA',
    parcours: [
      { id: 'profil', name: 'Profil psychotechnique', desc: 'Personnalité, intérêts, motivation', score: 'OK', status: 'done' },
      { id: 'sa',     name: 'Test SA', desc: 'Schémas et abstractions',                          score: '12.6', status: 'done' },
      { id: 'la',     name: 'Test LA', desc: 'Logique appliquée',                                score: '—',    status: 'active' },
      { id: 'meca',   name: 'Test MECA', desc: 'Raisonnement mécanique',                         score: '—',    status: 'pending' },
      { id: 'orient', name: 'Orientation finale', desc: 'Recommandations personnalisées',        score: '—',    status: 'pending' },
    ],
  },
  'conseiller1@capavenir.cm': {
    password: 'admin123',
    role: 'conseiller',
    name: 'Dr. Estelle Ngono',
    class: 'Conseillère principale · Yaoundé',
    initials: 'EN',
  },
  'conseiller2@capavenir.cm': {
    password: 'admin123',
    role: 'conseiller',
    name: 'M. Patrick Foning',
    class: 'Conseiller référent · Douala',
    initials: 'PF',
  },
};

/* Données mock pour le dashboard conseiller */
const STUDENTS_MOCK = [
  { initials: 'NM', name: 'Nadège Mballa',  class: 'Tle C',  progress: 65, score: 14.2, status: 'progress' },
  { initials: 'JT', name: 'Junior Tchakounté', class: '1ère D', progress: 40, score: 12.6, status: 'progress' },
  { initials: 'AK', name: 'Aïcha Kombo',    class: 'Tle A4', progress: 100, score: 16.4, status: 'success' },
  { initials: 'BE', name: 'Bertrand Eyenga',class: 'Tle S',  progress: 82, score: 13.8, status: 'progress' },
  { initials: 'MK', name: 'Marie Kemajou',  class: '1ère C', progress: 100, score: 15.1, status: 'success' },
  { initials: 'SO', name: 'Samuel Onana',   class: 'Tle D',  progress: 15, score: 0.0,  status: 'pending' },
];

const FILIERES_DISTRIBUTION = [
  { name: 'Sciences & Technologie', pct: 38 },
  { name: 'Sciences économiques',   pct: 24 },
  { name: 'Lettres modernes',       pct: 18 },
  { name: 'Sciences humaines',      pct: 12 },
  { name: 'Arts & Communication',   pct: 8  },
];

/* ----------------------------------------------------------------
   2. STATE & STORAGE KEYS
   ---------------------------------------------------------------- */
const STORAGE = {
  SESSION: 'capavenir.session',
  THEME:   'capavenir.theme',
};

let state = {
  user: null,    // { email, role, name, ... }
  view: 'login', // 'login' | 'app'
};


/* ----------------------------------------------------------------
   3. UTILS
   ---------------------------------------------------------------- */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

function escapeHTML(str = '') {
  return str.replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}


/* ----------------------------------------------------------------
   4. THÈME (light/dark)
   ---------------------------------------------------------------- */
function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem(STORAGE.THEME, theme);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'light';
  applyTheme(current === 'light' ? 'dark' : 'light');
}

function initTheme() {
  const saved = localStorage.getItem(STORAGE.THEME);
  const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
  applyTheme(saved || (prefersDark ? 'dark' : 'light'));
}


/* ----------------------------------------------------------------
   5. AUTH / SESSION
   ---------------------------------------------------------------- */
function login(email, password) {
  const account = ACCOUNTS[email.trim().toLowerCase()];
  if (!account || account.password !== password) {
    return { ok: false, error: 'Identifiants incorrects.' };
  }
  const user = {
    email: email.trim().toLowerCase(),
    role: account.role,
    name: account.name,
    class: account.class,
    initials: account.initials,
    progression: account.progression,
    tests_done: account.tests_done,
    avg_score: account.avg_score,
    next: account.next,
    parcours: account.parcours,
  };
  state.user = user;
  localStorage.setItem(STORAGE.SESSION, JSON.stringify(user));
  return { ok: true, user };
}

function logout() {
  localStorage.removeItem(STORAGE.SESSION);
  state.user = null;
  showView('login');
  // reset login form
  const form = $('#loginForm');
  if (form) form.reset();
  $('#formError').hidden = true;
}

function restoreSession() {
  try {
    const raw = localStorage.getItem(STORAGE.SESSION);
    if (!raw) return null;
    const user = JSON.parse(raw);
    state.user = user;
    return user;
  } catch (e) {
    return null;
  }
}


/* ----------------------------------------------------------------
   6. ROUTAGE DE VUES
   ---------------------------------------------------------------- */
function showView(name) {
  state.view = name;
  $('#view-login').hidden = (name !== 'login');
  $('#view-app').hidden   = (name !== 'app');
  window.scrollTo({ top: 0, behavior: 'instant' });
}


/* ----------------------------------------------------------------
   7. LOGIN — wiring
   ---------------------------------------------------------------- */
function initLogin() {
  const form = $('#loginForm');
  const emailInput = $('#email');
  const pwdInput = $('#password');
  const errorBox = $('#formError');
  const submitBtn = $('#loginSubmit');
  const reveal = $('#revealPwd');

  // Toggle visibilité mot de passe
  reveal.addEventListener('click', () => {
    const isPwd = pwdInput.type === 'password';
    pwdInput.type = isPwd ? 'text' : 'password';
  });

  // Comptes démo : pré-remplir
  $$('.demo-card').forEach(card => {
    card.addEventListener('click', () => {
      emailInput.value = card.dataset.email;
      pwdInput.value = card.dataset.pwd;
      errorBox.hidden = true;
      emailInput.focus();
    });
  });

  // Soumission
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    errorBox.hidden = true;

    const email = emailInput.value.trim();
    const pwd = pwdInput.value;

    if (!email || !pwd) {
      errorBox.querySelector('span').textContent = 'Veuillez remplir tous les champs.';
      errorBox.hidden = false;
      return;
    }

    // simule un léger délai réseau pour le feedback visuel
    submitBtn.classList.add('is-loading');
    setTimeout(() => {
      const res = login(email, pwd);
      submitBtn.classList.remove('is-loading');

      if (!res.ok) {
        errorBox.querySelector('span').textContent = res.error;
        errorBox.hidden = false;
        // petit shake sur l'input
        pwdInput.animate(
          [{ transform: 'translateX(0)' }, { transform: 'translateX(-6px)' },
           { transform: 'translateX(6px)' }, { transform: 'translateX(0)' }],
          { duration: 280 }
        );
        return;
      }
      enterApp();
    }, 420);
  });

  // Theme toggle (login)
  $('#loginThemeToggle').addEventListener('click', toggleTheme);
}


/* ----------------------------------------------------------------
   8. ENTRÉE APP — orchestration
   ---------------------------------------------------------------- */
function enterApp() {
  const user = state.user;
  if (!user) return;

  // User badge
  $('#userName').textContent = user.name;
  $('#userRole').textContent = user.role === 'eleve' ? 'Élève' : 'Conseiller';
  $('#userAvatar').textContent = user.initials || '?';

  // Nav header selon rôle
  renderHeaderNav(user.role);

  // Page head selon rôle
  renderPageHead(user);

  // Stepper
  renderStepper(user);

  // Métriques
  renderMetrics(user);

  // Alerte
  renderAlert(user);

  // Contenu principal
  renderContent(user);

  showView('app');
}


/* ----------------------------------------------------------------
   9. RENDU — header nav
   ---------------------------------------------------------------- */
function renderHeaderNav(role) {
  const nav = $('#headerNav');
  const items = role === 'eleve'
    ? ['Mon parcours', 'Mes tests', 'Résultats', 'Ressources']
    : ['Aperçu', 'Élèves', 'Analyses', 'Rapports'];
  nav.innerHTML = items.map((label, i) => `
    <button class="nav-item ${i === 0 ? 'is-active' : ''}">${label}</button>
  `).join('');
}


/* ----------------------------------------------------------------
   10. RENDU — Page head (titre + actions)
   ---------------------------------------------------------------- */
function renderPageHead(user) {
  const title = $('#pageTitle');
  const sub = $('#pageSub');
  const actions = $('#pageHeadActions');

  if (user.role === 'eleve') {
    const firstName = user.name.split(' ')[0];
    title.textContent = `Bonjour, ${firstName}.`;
    sub.textContent = user.class;
    actions.innerHTML = `
      <button class="btn btn-secondary">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
        Télécharger le rapport
      </button>
      <button class="btn btn-primary">
        <span class="btn-label">Continuer mon test</span>
        <svg class="btn-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </button>
    `;
  } else {
    title.textContent = `Bonjour, ${user.name.split(' ').slice(-1)}.`;
    sub.textContent = user.class;
    actions.innerHTML = `
      <button class="btn btn-secondary">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        Exporter
      </button>
      <button class="btn btn-primary">
        <span class="btn-label">Nouveau rapport</span>
        <svg class="btn-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </button>
    `;
  }
}


/* ----------------------------------------------------------------
   11. RENDU — STEPPER
   ---------------------------------------------------------------- */
function renderStepper(user) {
  const wrap = $('#stepperWrap');

  const steps = user.role === 'eleve'
    ? [
        { name: 'Profil',      done: true,  active: false },
        { name: 'Test SA',     done: true,  active: false },
        { name: 'Test LA',     done: user.progression >= 60, active: user.progression < 60 },
        { name: 'Test MECA',   done: false, active: user.progression >= 60 },
        { name: 'Orientation', done: false, active: false },
      ]
    : [
        { name: 'Aperçu',    done: false, active: true  },
        { name: 'Élèves',    done: false, active: false },
        { name: 'Analyses',  done: false, active: false },
        { name: 'Rapports',  done: false, active: false },
        { name: 'Paramètres',done: false, active: false },
      ];

  // S'assurer qu'au moins une étape est active pour l'élève
  if (user.role === 'eleve' && !steps.some(s => s.active)) {
    const idx = steps.findIndex(s => !s.done);
    if (idx >= 0) steps[idx].active = true;
  }

  const html = steps.map((s, i) => {
    const cls = ['step',
      s.done ? 'is-done' : '',
      s.active ? 'is-active' : ''
    ].filter(Boolean).join(' ');

    const stateLabel = s.done ? 'Terminé' : s.active ? 'En cours' : 'À faire';
    const numContent = s.done ? '✓' : String(i + 1).padStart(2, '0');

    const sep = i < steps.length - 1
      ? `<div class="step-sep ${s.done ? 'is-done' : ''}"></div>`
      : '';

    return `
      <div class="${cls}">
        <div class="step-num">${numContent}</div>
        <div class="step-label">
          <span class="step-name">${escapeHTML(s.name)}</span>
          <span class="step-state">${stateLabel}</span>
        </div>
      </div>
      ${sep}
    `;
  }).join('');

  wrap.innerHTML = html;

  // Permettre la navigation entre tabs pour conseiller
  if (user.role === 'conseiller') {
    $$('.step', wrap).forEach((stepEl, i) => {
      stepEl.addEventListener('click', () => {
        $$('.step', wrap).forEach(el => el.classList.remove('is-active'));
        stepEl.classList.add('is-active');
      });
    });
  }
}


/* ----------------------------------------------------------------
   12. RENDU — MÉTRIQUES
   ---------------------------------------------------------------- */
function renderMetrics(user) {
  const grid = $('#metricsGrid');

  const cards = user.role === 'eleve'
    ? [
        { label: 'Progression', value: user.progression, unit: '%', icon: 'trend', trend: '+15% cette semaine', progress: user.progression },
        { label: 'Tests terminés', value: user.tests_done, unit: '/5', icon: 'check' },
        { label: 'Score moyen', value: user.avg_score, unit: '/20', icon: 'star', trend: '+0.8 vs dernier', good: true },
        { label: 'Prochaine étape', value: user.next, icon: 'clock', small: true },
      ]
    : [
        { label: 'Élèves suivis', value: 128, icon: 'users', trend: '+12 ce mois' },
        { label: 'Tests complétés', value: 412, icon: 'check', trend: '+47 cette semaine' },
        { label: 'Taux de complétion', value: 78, unit: '%', icon: 'trend', trend: '+5%', progress: 78 },
        { label: 'Score moyen', value: 14.1, unit: '/20', icon: 'star', trend: 'Stable' },
      ];

  const iconSvg = {
    trend: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
    star:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
    users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
  };

  grid.innerHTML = cards.map(c => {
    const trendHtml = c.trend
      ? `<div class="metric-trend ${c.trendDown ? 'is-neg' : ''}">
           <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg>
           ${escapeHTML(c.trend)}
         </div>`
      : '';
    const progHtml = (typeof c.progress === 'number')
      ? `<div class="metric-progress"><div class="metric-progress-fill" style="width:0%" data-fill="${c.progress}"></div></div>`
      : '';
    const valStyle = c.small ? 'style="font-size:18px;line-height:1.2;"' : '';

    return `
      <div class="metric-card">
        <div class="metric-head">
          <span class="metric-label">${escapeHTML(c.label)}</span>
          <div class="metric-icon">${iconSvg[c.icon] || iconSvg.trend}</div>
        </div>
        <div class="metric-value" ${valStyle}>${escapeHTML(String(c.value))}${c.unit ? `<span class="unit">${escapeHTML(c.unit)}</span>` : ''}</div>
        ${trendHtml}
        ${progHtml}
      </div>
    `;
  }).join('');

  // Anime les barres de progression
  requestAnimationFrame(() => {
    $$('.metric-progress-fill', grid).forEach(el => {
      const pct = parseFloat(el.dataset.fill) || 0;
      el.style.width = pct + '%';
    });
  });
}


/* ----------------------------------------------------------------
   13. RENDU — Alert principal
   ---------------------------------------------------------------- */
function renderAlert(user) {
  const alertEl = $('#mainAlert');

  if (user.role === 'eleve') {
    alertEl.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
      <div class="alert-content">
        <div class="alert-title">Prochaine échéance : Test MECA</div>
        <div class="alert-text">Vous pouvez passer ce test à tout moment depuis votre espace. Durée estimée : 35 minutes. Pensez à le réaliser dans un environnement calme.</div>
      </div>
    `;
  } else {
    alertEl.classList.add('alert-warning');
    alertEl.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
      <div class="alert-content">
        <div class="alert-title">3 élèves sans activité depuis plus de 14 jours</div>
        <div class="alert-text">Samuel Onana, Cédric Talla et Lise Mvondo n'ont pas avancé sur leur parcours. Pensez à les relancer ou planifier un entretien.</div>
      </div>
    `;
  }
  alertEl.hidden = false;
}


/* ----------------------------------------------------------------
   14. RENDU — CONTENU PRINCIPAL (2 colonnes)
   ---------------------------------------------------------------- */
function renderContent(user) {
  const grid = $('#contentGrid');

  if (user.role === 'eleve') {
    grid.innerHTML = `
      <!-- Colonne gauche : parcours -->
      <section class="panel">
        <header class="panel-head">
          <div>
            <div class="panel-title">Mon parcours</div>
          </div>
          <a href="#" class="panel-action">Voir le détail →</a>
        </header>
        <div class="panel-body">
          <div class="parcours-list">
            ${user.parcours.map(p => `
              <div class="parcours-row">
                <div class="parcours-icon">${parcoursIcon(p.id)}</div>
                <div class="parcours-content">
                  <div class="parcours-name">${escapeHTML(p.name)}</div>
                  <div class="parcours-desc">${escapeHTML(p.desc)}</div>
                </div>
                <div class="parcours-score">${p.score === '—' ? '<span class="parcours-status ' + statusClass(p.status) + '">' + statusLabel(p.status) + '</span>' : p.score + (p.score !== 'OK' ? '<span class="unit">/20</span>' : '')}</div>
              </div>
            `).join('')}
          </div>
        </div>
      </section>

      <!-- Colonne droite : chat IA -->
      ${chatPanelHtml(user.role)}
    `;
  } else {
    grid.innerHTML = `
      <!-- Colonne gauche : table d'élèves -->
      <section class="panel">
        <header class="panel-head">
          <div>
            <div class="panel-title">Mes élèves récents</div>
          </div>
          <a href="#" class="panel-action">Tout voir →</a>
        </header>
        <div class="panel-body" style="padding: 0;">
          <table class="students-table">
            <thead>
              <tr>
                <th>Élève</th>
                <th>Classe</th>
                <th>Progression</th>
                <th>Moyenne</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              ${STUDENTS_MOCK.map(s => `
                <tr>
                  <td>
                    <div class="student-cell">
                      <div class="student-avatar">${s.initials}</div>
                      <div>
                        <div class="student-name">${escapeHTML(s.name)}</div>
                      </div>
                    </div>
                  </td>
                  <td><span class="student-class">${escapeHTML(s.class)}</span></td>
                  <td>
                    <span class="progress-bar"><span class="progress-fill" style="width:${s.progress}%"></span></span>
                    <span style="font-size:12px; font-weight:600; color:var(--text-2);">${s.progress}%</span>
                  </td>
                  <td>
                    <span style="font-family:var(--font-display); font-weight:700;">${s.score > 0 ? s.score.toFixed(1) : '—'}</span>
                  </td>
                  <td>
                    <span class="tag tag-${s.status === 'success' ? 'success' : s.status === 'progress' ? 'progress' : 'pending'}">
                      ${s.status === 'success' ? 'Terminé' : s.status === 'progress' ? 'En cours' : 'Inactif'}
                    </span>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </section>

      <!-- Colonne droite : distribution + chat -->
      <div style="display:flex; flex-direction:column; gap: var(--s-6);">
        <section class="panel">
          <header class="panel-head">
            <div class="panel-title">Filières recommandées</div>
            <span class="panel-action">Ce trimestre</span>
          </header>
          <div class="panel-body">
            <div class="distrib-list">
              ${FILIERES_DISTRIBUTION.map(f => `
                <div class="distrib-row">
                  <div class="distrib-head">
                    <span class="distrib-name">${escapeHTML(f.name)}</span>
                    <span class="distrib-value">${f.pct}%</span>
                  </div>
                  <div class="distrib-track">
                    <div class="distrib-fill" style="width:0%" data-fill="${f.pct}"></div>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        </section>

        ${chatPanelHtml(user.role)}
      </div>
    `;

    // anime les barres
    requestAnimationFrame(() => {
      $$('.distrib-fill', grid).forEach(el => {
        const pct = parseFloat(el.dataset.fill) || 0;
        el.style.width = pct + '%';
      });
    });
  }

  // wiring du chat
  initChat(user.role);
}


function parcoursIcon(id) {
  const icons = {
    profil: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
    sa:     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>',
    la:     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
    meca:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
    orient: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></svg>',
  };
  return icons[id] || icons.profil;
}
function statusClass(s) {
  return s === 'done' ? 'is-done' : s === 'active' ? 'is-active' : '';
}
function statusLabel(s) {
  return s === 'done' ? 'Terminé' : s === 'active' ? 'À passer' : 'Bloqué';
}


/* ----------------------------------------------------------------
   15. CHAT IA SIMULÉ
   ---------------------------------------------------------------- */
function chatPanelHtml(role) {
  const subtitle = role === 'eleve'
    ? 'Posez vos questions sur votre orientation'
    : 'Aide à la décision · contexte conseiller';
  return `
    <section class="panel chat-panel">
      <header class="panel-head chat-head">
        <div>
          <div class="chat-title-row">
            <span class="chat-pulse"></span>
            <span class="panel-title">Assistant IA CapAvenir</span>
          </div>
          <div class="chat-sub">${subtitle}</div>
        </div>
      </header>
      <div class="chat-body" id="chatBody"></div>
      <footer class="chat-foot">
        <div class="chat-input-wrap">
          <input type="text" class="chat-input" id="chatInput" placeholder="${role === 'eleve' ? 'Quelle filière correspond à mon profil ?' : 'Analyser le profil de Nadège Mballa…'}" />
          <button class="chat-send" id="chatSend" aria-label="Envoyer">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          </button>
        </div>
      </footer>
    </section>
  `;
}

/* Réponses simulées de l'IA */
const AI_RESPONSES = {
  eleve: [
    "Avec vos scores actuels (SA 15.8, LA 14.1), le profil sciences-techniques est cohérent. Je recommande de finaliser le test MECA pour confirmer votre aptitude au raisonnement appliqué.",
    "Excellente question. D'après votre parcours, trois filières ressortent : ingénierie, sciences économiques appliquées, et architecture. Voulez-vous une analyse comparative ?",
    "Votre profil montre une forte logique abstraite mais une motivation modérée pour les sciences pures. Avez-vous envisagé les filières d'analyse de données ou de finance quantitative ?",
    "Pour préparer le test MECA, je vous suggère de revoir les principes de leviers, poulies et engrenages. Comptez 35 minutes de test en environnement calme.",
  ],
  conseiller: [
    "Le profil de Nadège Mballa (Tle C) présente un score SA de 15.8 et LA de 14.1 — au-dessus de la moyenne nationale (12.3). Profil cohérent pour les classes prépa scientifiques.",
    "Sur les 128 élèves suivis ce trimestre, 12 affichent un profil 'orientation incertaine' (score < 10 sur 2 tests). Je peux générer leur liste pour un entretien prioritaire.",
    "La distribution actuelle des filières recommandées est cohérente avec la moyenne nationale 2025. Légère sur-représentation des sciences (+4 pts), normale pour un établissement urbain.",
    "Pour Samuel Onana (inactif depuis 18 jours), trois actions possibles : relance par e-mail, convocation entretien, ou prise de contact avec les parents. Quelle option privilégier ?",
  ],
};

function initChat(role) {
  const body = $('#chatBody');
  const input = $('#chatInput');
  const send = $('#chatSend');

  // Messages initiaux
  const opener = role === 'eleve'
    ? "Bonjour ! Je suis votre assistant CapAvenir. Je peux vous aider à comprendre vos résultats, choisir une filière, ou préparer vos prochains tests. Que souhaitez-vous explorer ?"
    : "Bonjour. Je peux analyser vos élèves, comparer leurs profils, générer des recommandations d'orientation ou produire des rapports synthétiques. Par quoi commençons-nous ?";

  body.innerHTML = '';
  appendBubble(body, 'ai', opener);

  // Envoi
  const sendMessage = () => {
    const text = input.value.trim();
    if (!text) return;
    appendBubble(body, 'user', text);
    input.value = '';
    body.scrollTop = body.scrollHeight;

    // typing indicator
    const typing = document.createElement('div');
    typing.className = 'bubble-block is-ai';
    typing.innerHTML = `<div class="bubble bubble-ai bubble-typing"><span></span><span></span><span></span></div>`;
    body.appendChild(typing);
    body.scrollTop = body.scrollHeight;

    // réponse simulée après 800-1400ms
    const delay = 800 + Math.random() * 600;
    setTimeout(() => {
      typing.remove();
      const responses = AI_RESPONSES[role];
      const response = responses[Math.floor(Math.random() * responses.length)];
      appendBubble(body, 'ai', response);
      body.scrollTop = body.scrollHeight;
    }, delay);
  };

  send.addEventListener('click', sendMessage);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') sendMessage();
  });
}

function appendBubble(container, who, text) {
  const block = document.createElement('div');
  block.className = `bubble-block ${who === 'user' ? 'is-user' : 'is-ai'}`;
  block.innerHTML = `
    <div class="bubble-role">${who === 'user' ? 'Vous' : 'IA'}</div>
    <div class="bubble bubble-${who === 'user' ? 'user' : 'ai'}">${escapeHTML(text)}</div>
  `;
  container.appendChild(block);
}


/* ----------------------------------------------------------------
   16. USER DROPDOWN (logout)
   ---------------------------------------------------------------- */
function initUserMenu() {
  const badge = $('#userBadge');
  const dropdown = $('#userDropdown');
  const logoutBtn = $('#logoutBtn');

  badge.addEventListener('click', (e) => {
    e.stopPropagation();
    dropdown.hidden = !dropdown.hidden;
  });

  document.addEventListener('click', (e) => {
    if (!badge.contains(e.target)) dropdown.hidden = true;
  });

  logoutBtn.addEventListener('click', () => {
    dropdown.hidden = true;
    logout();
  });

  $('#appThemeToggle').addEventListener('click', toggleTheme);
}


/* ----------------------------------------------------------------
   17. INIT
   ---------------------------------------------------------------- */
function init() {
  initTheme();
  initLogin();
  initUserMenu();

  // Restaure la session si elle existe
  const user = restoreSession();
  if (user) {
    enterApp();
  } else {
    showView('login');
  }
}

document.addEventListener('DOMContentLoaded', init);
